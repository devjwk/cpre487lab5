# CprE 487 587 Lab 5 Team 06 Source Package

This archive follows the Lab 5 Section 8.2 layout. It contains four configured software framework copies, all seven tested XSA files, the three hardware IP implementations, the executed notebook, helper scripts, and board logs.

## Environment

```bash
source /remote/Xilinx/2020.1/Vitis/2020.1/settings64.sh
```

The data file server must be running before flashing. Each software folder includes the model and test-image data used by its build.

## Fixed-width builds

Run these commands from the matching software folder. The folder defaults already select its indicated operand width.

### 8-bit staged

```bash
cd sw/8bit_integrated_framework
./scripts/create_vitis -xsa_path ../../hw/8bit_mac/staged_mac.xsa -workspace_dir workspace/staged
./scripts/flash_vitis -workspace_dir workspace/staged
```

### 8-bit pipelined

```bash
cd sw/8bit_integrated_framework
./scripts/create_vitis -xsa_path ../../hw/8bit_mac/piped_mac.xsa -workspace_dir workspace/piped
./scripts/flash_vitis -workspace_dir workspace/piped
```

### 4-bit staged or pipelined

```bash
cd sw/4bit_integrated_framework
./scripts/create_vitis -xsa_path ../../hw/4bit_mac/staged_mac.xsa -workspace_dir workspace/staged
./scripts/flash_vitis -workspace_dir workspace/staged

./scripts/create_vitis -xsa_path ../../hw/4bit_mac/piped_mac.xsa -workspace_dir workspace/piped
./scripts/flash_vitis -workspace_dir workspace/piped
```

### 2-bit staged or pipelined

```bash
cd sw/2bit_integrated_framework
./scripts/create_vitis -xsa_path ../../hw/2bit_mac/staged_mac.xsa -workspace_dir workspace/staged
./scripts/flash_vitis -workspace_dir workspace/staged

./scripts/create_vitis -xsa_path ../../hw/2bit_mac/piped_mac.xsa -workspace_dir workspace/piped
./scripts/flash_vitis -workspace_dir workspace/piped
```

## Variable-precision build

The variable folder defaults to `QUANT_VARIABLE=yes`. Its calibrated layer widths are 8/4/8/4/4/4/4/8.

```bash
cd sw/variable_integrated_framework
./scripts/create_vitis -xsa_path ../../hw/variable_mac/variable_mac.xsa -workspace_dir workspace/variable
./scripts/flash_vitis -workspace_dir workspace/variable
```

Expected board result: every fixed-width and variable build reports all 13 layers matching. The variable build also reports PASS for exhaustive 8-, 4-, and 2-bit operand-pair self-tests.

## Hardware layout

- `hw/8bit_mac`, `hw/4bit_mac`, and `hw/2bit_mac` each contain staged and pipelined XSA files plus their shared configurable IP sources and reports.
- `hw/variable_mac` contains the variable-precision XSA, VHDL, testbench, Vivado scripts, and reports.
- `util/board_logs` contains the recorded ZedBoard runs used in the report.
